#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Data::SQLite;
using namespace Microsoft::Office::Interop::Excel;


namespace UserTest {

	/// <summary>
	/// ������ ��� Control4
	/// </summary>
	public ref class Control4 : public System::Windows::Forms::UserControl
	{
	private:String^ conect = "Data Source = .\\mat.db";
	private: SQLiteConnection^ con = gcnew SQLiteConnection(conect);

	public:
		Control4(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Control4()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	protected:
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ otch_select;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Label^ mea_lab;
	private: System::Windows::Forms::Label^ name_lab;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ nom_find;
	private: System::Windows::Forms::TextBox^ date_find;
	private: System::Windows::Forms::Button^ excel;
	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->otch_select = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->mea_lab = (gcnew System::Windows::Forms::Label());
			this->name_lab = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->nom_find = (gcnew System::Windows::Forms::TextBox());
			this->date_find = (gcnew System::Windows::Forms::TextBox());
			this->excel = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->panel1->BackColor = System::Drawing::Color::Linen;
			this->panel1->Controls->Add(this->label1);
			this->panel1->Location = System::Drawing::Point(3, 3);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(1230, 58);
			this->panel1->TabIndex = 25;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Ubuntu", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(21, 11);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(460, 29);
			this->label1->TabIndex = 7;
			this->label1->Text = L"����� �� ������� ���������� �� ������";
			// 
			// otch_select
			// 
			this->otch_select->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->otch_select->BackColor = System::Drawing::Color::LightSalmon;
			this->otch_select->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->otch_select->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->otch_select->Location = System::Drawing::Point(893, 359);
			this->otch_select->Name = L"otch_select";
			this->otch_select->Size = System::Drawing::Size(255, 41);
			this->otch_select->TabIndex = 6;
			this->otch_select->Text = L"������� �����";
			this->otch_select->UseVisualStyleBackColor = false;
			this->otch_select->Click += gcnew System::EventHandler(this, &Control4::otch_select_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Control;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Ubuntu Light", 8.999999F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::WindowText;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle2->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 8.999999F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle2->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle2->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle2->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle2;
			this->dataGridView1->Location = System::Drawing::Point(3, 67);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(792, 654);
			this->dataGridView1->TabIndex = 24;
			// 
			// panel2
			// 
			this->panel2->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->panel2->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel2->Controls->Add(this->mea_lab);
			this->panel2->Controls->Add(this->name_lab);
			this->panel2->Controls->Add(this->label2);
			this->panel2->Controls->Add(this->nom_find);
			this->panel2->Controls->Add(this->date_find);
			this->panel2->Location = System::Drawing::Point(842, 145);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(360, 165);
			this->panel2->TabIndex = 26;
			// 
			// mea_lab
			// 
			this->mea_lab->AutoSize = true;
			this->mea_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->mea_lab->Location = System::Drawing::Point(46, 109);
			this->mea_lab->Name = L"mea_lab";
			this->mea_lab->Size = System::Drawing::Size(138, 21);
			this->mea_lab->TabIndex = 6;
			this->mea_lab->Text = L"���� ���������";
			// 
			// name_lab
			// 
			this->name_lab->AutoSize = true;
			this->name_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->name_lab->Location = System::Drawing::Point(64, 53);
			this->name_lab->Name = L"name_lab";
			this->name_lab->Size = System::Drawing::Size(120, 21);
			this->name_lab->TabIndex = 5;
			this->name_lab->Text = L"� ���������";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(156, 9);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(54, 21);
			this->label2->TabIndex = 0;
			this->label2->Text = L"����:";
			// 
			// nom_find
			// 
			this->nom_find->Location = System::Drawing::Point(206, 53);
			this->nom_find->Multiline = true;
			this->nom_find->Name = L"nom_find";
			this->nom_find->Size = System::Drawing::Size(137, 32);
			this->nom_find->TabIndex = 2;
			// 
			// date_find
			// 
			this->date_find->Location = System::Drawing::Point(206, 109);
			this->date_find->Multiline = true;
			this->date_find->Name = L"date_find";
			this->date_find->Size = System::Drawing::Size(137, 32);
			this->date_find->TabIndex = 3;
			// 
			// excel
			// 
			this->excel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->excel->BackColor = System::Drawing::Color::Tomato;
			this->excel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->excel->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->excel->Location = System::Drawing::Point(911, 468);
			this->excel->Name = L"excel";
			this->excel->Size = System::Drawing::Size(208, 37);
			this->excel->TabIndex = 27;
			this->excel->Text = L"��������� � Excel";
			this->excel->UseVisualStyleBackColor = false;
			this->excel->Click += gcnew System::EventHandler(this, &Control4::excel_Click);
			// 
			// Control4
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Snow;
			this->Controls->Add(this->excel);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->otch_select);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->panel2);
			this->Name = L"Control4";
			this->Size = System::Drawing::Size(1237, 725);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void otch_select_Click(System::Object^ sender, System::EventArgs^ e) {
		
		try {
			dataGridView1->Columns->Clear();
			con->Open();
			String^ command1 = "select name_tab.������������, prih_tab.[� ���������],(prih_tab.[����������] - otp_tab.����������)\
 As [����������� ����������], (prih_tab.[�����] - otp_tab.�����) AS[����������� �����] \
from prih_tab join name_tab on prih_tab.id = name_tab.id \
join otp_tab on prih_tab.id = otp_tab.id \
where prih_tab.[� ���������] = '"+this->nom_find->Text+"' and prih_tab.������������ = name_tab.������������; ";
			SQLiteCommand^ cmd1 = gcnew SQLiteCommand(command1, con);
			dataGridView1->Columns->Add("Column1", "����");
			SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
			sda->SelectCommand = cmd1;
			System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
			sda->Fill(dbdataset);
			BindingSource^ bSource = gcnew BindingSource();
			bSource->DataSource = dbdataset;
			dataGridView1->DataSource = bSource;
			for each (DataGridViewRow ^ row in dataGridView1->Rows)
			{
				row->Cells[0]->Value = date_find->Text;
			}
			

			sda->Update(dbdataset);
			
		}
		finally {
			if (con != nullptr)
			{
				con->Close();
			}
		}
	}
private: System::Void excel_Click(System::Object^ sender, System::EventArgs^ e) {
	Microsoft::Office::Interop::Excel::Application^ exApp = gcnew Microsoft::Office::Interop::Excel::ApplicationClass();
	exApp->Workbooks->Add(Type::Missing);
	Microsoft::Office::Interop::Excel::Worksheet^ wsh = (Microsoft::Office::Interop::Excel::Worksheet^)exApp->ActiveSheet;
	int i, j;
	for (i = 0; i < dataGridView1->RowCount; i++)
	{
		for (j = 0; j < dataGridView1->ColumnCount; j++)
		{
			wsh->Cells[1, j+1] = dataGridView1->Columns[j]->HeaderText->ToString();
			wsh->Cells[i +2, j+1 ] = dataGridView1[j, i]->Value->ToString();
		}
	}
	exApp->Visible = true;
}
};
}
