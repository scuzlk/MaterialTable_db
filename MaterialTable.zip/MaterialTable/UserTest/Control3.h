#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Data::SQLite;
using namespace Microsoft::Office::Interop::Excel;



namespace UserTest {

	/// <summary>
	/// ������ ��� Control3
	/// </summary>
	public ref class Control3 : public System::Windows::Forms::UserControl
	{
	private: String^ conect = "Data Source = .\\mat.db";
	private: SQLiteConnection^ con = gcnew SQLiteConnection(conect);
	public:
		Control3(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Control3()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	protected:
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ tabl_select2;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::TextBox^ summ_box2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TextBox^ name_box2;
	private: System::Windows::Forms::TextBox^ kolvo_box2;
	private: System::Windows::Forms::TextBox^ price_box2;
	private: System::Windows::Forms::Label^ mea_lab;
	private: System::Windows::Forms::Label^ name_lab;
	private: System::Windows::Forms::Label^ id_lab;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ id_box2;
	private: System::Windows::Forms::TextBox^ nom_box2;
	private: System::Windows::Forms::TextBox^ date_box2;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::TableLayoutPanel^ tableLayoutPanel1;
	private: System::Windows::Forms::Button^ del_but2;
	private: System::Windows::Forms::Button^ insert_but2;
	private: System::Windows::Forms::Button^ update_but2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::ToolTip^ toolTip1;
	private: System::Windows::Forms::Button^ excel;
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->tabl_select2 = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->summ_box2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->name_box2 = (gcnew System::Windows::Forms::TextBox());
			this->kolvo_box2 = (gcnew System::Windows::Forms::TextBox());
			this->price_box2 = (gcnew System::Windows::Forms::TextBox());
			this->mea_lab = (gcnew System::Windows::Forms::Label());
			this->name_lab = (gcnew System::Windows::Forms::Label());
			this->id_lab = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->id_box2 = (gcnew System::Windows::Forms::TextBox());
			this->nom_box2 = (gcnew System::Windows::Forms::TextBox());
			this->date_box2 = (gcnew System::Windows::Forms::TextBox());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->del_but2 = (gcnew System::Windows::Forms::Button());
			this->insert_but2 = (gcnew System::Windows::Forms::Button());
			this->update_but2 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->toolTip1 = (gcnew System::Windows::Forms::ToolTip(this->components));
			this->excel = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->panel2->SuspendLayout();
			this->panel3->SuspendLayout();
			this->tableLayoutPanel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->panel1->BackColor = System::Drawing::Color::Linen;
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->tabl_select2);
			this->panel1->Location = System::Drawing::Point(3, 3);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(1230, 58);
			this->panel1->TabIndex = 21;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Ubuntu", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(21, 11);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(337, 29);
			this->label1->TabIndex = 7;
			this->label1->Text = L"������ ���������� �� ������";
			// 
			// tabl_select2
			// 
			this->tabl_select2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->tabl_select2->BackColor = System::Drawing::Color::LightSalmon;
			this->tabl_select2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->tabl_select2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->tabl_select2->Location = System::Drawing::Point(959, 7);
			this->tabl_select2->Name = L"tabl_select2";
			this->tabl_select2->Size = System::Drawing::Size(255, 41);
			this->tabl_select2->TabIndex = 6;
			this->tabl_select2->Text = L"������� �������";
			this->tabl_select2->UseVisualStyleBackColor = false;
			this->tabl_select2->Click += gcnew System::EventHandler(this, &Control3::tabl_select2_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			dataGridViewCellStyle1->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle1->BackColor = System::Drawing::SystemColors::Control;
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"Ubuntu Light", 8.999999F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle1->ForeColor = System::Drawing::SystemColors::WindowText;
			dataGridViewCellStyle1->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle1->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle1->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle2->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 8.999999F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle2->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle2->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle2->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle2->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle2;
			this->dataGridView1->Location = System::Drawing::Point(3, 67);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(792, 654);
			this->dataGridView1->TabIndex = 20;
			// 
			// panel2
			// 
			this->panel2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->panel2->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel2->Controls->Add(this->label7);
			this->panel2->Controls->Add(this->summ_box2);
			this->panel2->Controls->Add(this->label4);
			this->panel2->Controls->Add(this->label5);
			this->panel2->Controls->Add(this->label6);
			this->panel2->Controls->Add(this->name_box2);
			this->panel2->Controls->Add(this->kolvo_box2);
			this->panel2->Controls->Add(this->price_box2);
			this->panel2->Controls->Add(this->mea_lab);
			this->panel2->Controls->Add(this->name_lab);
			this->panel2->Controls->Add(this->id_lab);
			this->panel2->Controls->Add(this->label2);
			this->panel2->Controls->Add(this->id_box2);
			this->panel2->Controls->Add(this->nom_box2);
			this->panel2->Controls->Add(this->date_box2);
			this->panel2->Location = System::Drawing::Point(797, 67);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(436, 404);
			this->panel2->TabIndex = 22;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label7->Location = System::Drawing::Point(177, 356);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(66, 21);
			this->label7->TabIndex = 14;
			this->label7->Text = L"�����";
			// 
			// summ_box2
			// 
			this->summ_box2->Location = System::Drawing::Point(265, 358);
			this->summ_box2->Multiline = true;
			this->summ_box2->Name = L"summ_box2";
			this->summ_box2->Size = System::Drawing::Size(137, 32);
			this->summ_box2->TabIndex = 13;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(192, 304);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(51, 21);
			this->label4->TabIndex = 12;
			this->label4->Text = L"����";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(138, 250);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(105, 21);
			this->label5->TabIndex = 11;
			this->label5->Text = L"����������";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label6->Location = System::Drawing::Point(115, 198);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(128, 21);
			this->label6->TabIndex = 10;
			this->label6->Text = L"������������";
			// 
			// name_box2
			// 
			this->name_box2->Location = System::Drawing::Point(265, 198);
			this->name_box2->Multiline = true;
			this->name_box2->Name = L"name_box2";
			this->name_box2->Size = System::Drawing::Size(137, 32);
			this->name_box2->TabIndex = 7;
			// 
			// kolvo_box2
			// 
			this->kolvo_box2->Location = System::Drawing::Point(265, 250);
			this->kolvo_box2->Multiline = true;
			this->kolvo_box2->Name = L"kolvo_box2";
			this->kolvo_box2->Size = System::Drawing::Size(137, 32);
			this->kolvo_box2->TabIndex = 8;
			// 
			// price_box2
			// 
			this->price_box2->Location = System::Drawing::Point(265, 306);
			this->price_box2->Multiline = true;
			this->price_box2->Name = L"price_box2";
			this->price_box2->Size = System::Drawing::Size(137, 32);
			this->price_box2->TabIndex = 9;
			// 
			// mea_lab
			// 
			this->mea_lab->AutoSize = true;
			this->mea_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->mea_lab->Location = System::Drawing::Point(105, 149);
			this->mea_lab->Name = L"mea_lab";
			this->mea_lab->Size = System::Drawing::Size(138, 21);
			this->mea_lab->TabIndex = 6;
			this->mea_lab->Text = L"���� ���������";
			// 
			// name_lab
			// 
			this->name_lab->AutoSize = true;
			this->name_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->name_lab->Location = System::Drawing::Point(123, 93);
			this->name_lab->Name = L"name_lab";
			this->name_lab->Size = System::Drawing::Size(120, 21);
			this->name_lab->TabIndex = 5;
			this->name_lab->Text = L"� ���������";
			// 
			// id_lab
			// 
			this->id_lab->AutoSize = true;
			this->id_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->id_lab->Location = System::Drawing::Point(218, 41);
			this->id_lab->Name = L"id_lab";
			this->id_lab->Size = System::Drawing::Size(25, 21);
			this->id_lab->TabIndex = 4;
			this->id_lab->Text = L"Id";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(156, 9);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(71, 21);
			this->label2->TabIndex = 0;
			this->label2->Text = L"������:";
			// 
			// id_box2
			// 
			this->id_box2->Location = System::Drawing::Point(265, 41);
			this->id_box2->Multiline = true;
			this->id_box2->Name = L"id_box2";
			this->id_box2->Size = System::Drawing::Size(137, 32);
			this->id_box2->TabIndex = 1;
			// 
			// nom_box2
			// 
			this->nom_box2->Location = System::Drawing::Point(265, 93);
			this->nom_box2->Multiline = true;
			this->nom_box2->Name = L"nom_box2";
			this->nom_box2->Size = System::Drawing::Size(137, 32);
			this->nom_box2->TabIndex = 2;
			// 
			// date_box2
			// 
			this->date_box2->Location = System::Drawing::Point(265, 149);
			this->date_box2->Multiline = true;
			this->date_box2->Name = L"date_box2";
			this->date_box2->Size = System::Drawing::Size(137, 32);
			this->date_box2->TabIndex = 3;
			// 
			// panel3
			// 
			this->panel3->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->panel3->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel3->Controls->Add(this->tableLayoutPanel1);
			this->panel3->Controls->Add(this->label3);
			this->panel3->Location = System::Drawing::Point(797, 509);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(436, 112);
			this->panel3->TabIndex = 23;
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 3;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50.3876F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				49.6124F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				149)));
			this->tableLayoutPanel1->Controls->Add(this->del_but2, 2, 0);
			this->tableLayoutPanel1->Controls->Add(this->insert_but2, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->update_but2, 1, 0);
			this->tableLayoutPanel1->Location = System::Drawing::Point(27, 52);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 1;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 50)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(394, 43);
			this->tableLayoutPanel1->TabIndex = 12;
			// 
			// del_but2
			// 
			this->del_but2->BackColor = System::Drawing::Color::LightSalmon;
			this->del_but2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->del_but2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->del_but2->Location = System::Drawing::Point(247, 3);
			this->del_but2->Name = L"del_but2";
			this->del_but2->Size = System::Drawing::Size(114, 31);
			this->del_but2->TabIndex = 10;
			this->del_but2->Text = L"�������";
			this->toolTip1->SetToolTip(this->del_but2, L"��� �������� ������ ���������� ������ ������ id");
			this->del_but2->UseVisualStyleBackColor = false;
			this->del_but2->Click += gcnew System::EventHandler(this, &Control3::del_but2_Click);
			// 
			// insert_but2
			// 
			this->insert_but2->BackColor = System::Drawing::Color::LightSalmon;
			this->insert_but2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->insert_but2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->insert_but2->Location = System::Drawing::Point(3, 3);
			this->insert_but2->Name = L"insert_but2";
			this->insert_but2->Size = System::Drawing::Size(114, 31);
			this->insert_but2->TabIndex = 4;
			this->insert_but2->Text = L"��������";
			this->insert_but2->UseVisualStyleBackColor = false;
			this->insert_but2->Click += gcnew System::EventHandler(this, &Control3::insert_but2_Click);
			// 
			// update_but2
			// 
			this->update_but2->BackColor = System::Drawing::Color::LightSalmon;
			this->update_but2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->update_but2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->update_but2->Location = System::Drawing::Point(126, 3);
			this->update_but2->Name = L"update_but2";
			this->update_but2->Size = System::Drawing::Size(114, 31);
			this->update_but2->TabIndex = 9;
			this->update_but2->Text = L"��������";
			this->update_but2->UseVisualStyleBackColor = false;
			this->update_but2->Click += gcnew System::EventHandler(this, &Control3::update_but2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(109, 15);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(189, 21);
			this->label3->TabIndex = 0;
			this->label3->Text = L"���������� ��������";
			// 
			// toolTip1
			// 
			this->toolTip1->AutomaticDelay = 400;
			// 
			// excel
			// 
			this->excel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->excel->BackColor = System::Drawing::Color::Tomato;
			this->excel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->excel->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->excel->Location = System::Drawing::Point(917, 650);
			this->excel->Name = L"excel";
			this->excel->Size = System::Drawing::Size(208, 37);
			this->excel->TabIndex = 24;
			this->excel->Text = L"��������� � Excel";
			this->excel->UseVisualStyleBackColor = false;
			this->excel->Click += gcnew System::EventHandler(this, &Control3::excel_Click);
			// 
			// Control3
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Snow;
			this->Controls->Add(this->excel);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel3);
			this->Name = L"Control3";
			this->Size = System::Drawing::Size(1237, 725);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->tableLayoutPanel1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void tabl_select2_Click(System::Object^ sender, System::EventArgs^ e) {
		
		try {
			con->Open();
			SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
			SQLiteCommand^ cmd = gcnew SQLiteCommand("Select * From otp_tab;", con);
			sda->SelectCommand = cmd;
			System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
			sda->Fill(dbdataset);
			BindingSource^ bSource = gcnew BindingSource();
			bSource->DataSource = dbdataset;
			dataGridView1->DataSource = bSource;
			sda->Update(dbdataset);
		}
		finally {
			if (con != nullptr)
			{
				con->Close();
			}
		}
	}
private: System::Void insert_but2_Click(System::Object^ sender, System::EventArgs^ e) {
	
	try {
		con->Open();
		SQLiteDataReader^ myReader;
		String^ command2 = "insert into otp_tab(id,[� ���������],[���� ���������],������������,����������,����,�����)\
 values ('" + this->id_box2->Text + "','" + this->nom_box2->Text + "','" + this->date_box2->Text + "','" + this->name_box2->Text + "','" + this->kolvo_box2->Text + "','" + this->price_box2->Text + "','" + this->summ_box2->Text + "');";
		SQLiteCommand^ cmd2 = gcnew SQLiteCommand(command2, con);
		myReader = cmd2->ExecuteReader();
		this->name_box2->Clear();
		this->id_box2->Clear();
		this->nom_box2->Clear();
		this->date_box2->Clear();
		this->kolvo_box2->Clear();
		this->price_box2->Clear();
		this->summ_box2->Clear();
		while (myReader->Read())
		{
		}
		con->Close();

		con->Open();
		SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
		SQLiteCommand^ cmd6 = gcnew SQLiteCommand("Select * From otp_tab;", con);
		sda->SelectCommand = cmd6;
		System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
		sda->Fill(dbdataset);
		BindingSource^ bSource = gcnew BindingSource();
		bSource->DataSource = dbdataset;
		dataGridView1->DataSource = bSource;
		sda->Update(dbdataset);
	}
	finally {
		if (con != nullptr)
		{
			con->Close();
		}
	}
}
private: System::Void update_but2_Click(System::Object^ sender, System::EventArgs^ e) {
	
	try {
		con->Open();
		SQLiteDataReader^ myReader;
		String^ command1 = "update otp_tab set [� ���������] = '" + this->nom_box2->Text + "',\
[���� ���������] = '" + this->date_box2->Text + "',������������ = '" + this->name_box2->Text + "',\
����������= '" + this->kolvo_box2->Text + "',���� = '" + this->price_box2->Text + "',\
����� = '" + this->summ_box2->Text + "' where id = '" + this->id_box2->Text + "';";
		String^ command2 = "update name_tab set ������������ = '" + this->name_box2->Text + "' where id = '" + this->id_box2->Text + "';";
		String^ command3 = "update prih_tab set ������������ = '" + this->name_box2->Text + "' where id = '" + this->id_box2->Text + "';";
		String^ command4 = "update otchet_tab set ������������ = '" + this->name_box2->Text + "' where id = '" + this->id_box2->Text + "';";
		SQLiteCommand^ cmd1 = gcnew SQLiteCommand(command1, con);
		myReader = cmd1->ExecuteReader();
		SQLiteCommand^ cmd2 = gcnew SQLiteCommand(command2, con);
		myReader = cmd2->ExecuteReader();
		SQLiteCommand^ cmd3 = gcnew SQLiteCommand(command3, con);
		myReader = cmd3->ExecuteReader();
		SQLiteCommand^ cmd4 = gcnew SQLiteCommand(command4, con);
		myReader = cmd4->ExecuteReader();
		this->name_box2->Clear();
		this->id_box2->Clear();
		this->nom_box2->Clear();
		this->date_box2->Clear();
		this->kolvo_box2->Clear();
		this->price_box2->Clear();
		this->summ_box2->Clear();
		while (myReader->Read())
		{
		}
		con->Close();

		con->Open();
		SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
		SQLiteCommand^ cmd6 = gcnew SQLiteCommand("Select * From otp_tab;", con);
		sda->SelectCommand = cmd6;
		System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
		sda->Fill(dbdataset);
		BindingSource^ bSource = gcnew BindingSource();
		bSource->DataSource = dbdataset;
		dataGridView1->DataSource = bSource;
		sda->Update(dbdataset);
	}
	finally {
		if (con != nullptr)
		{
			con->Close();
		}
	}
}
private: System::Void del_but2_Click(System::Object^ sender, System::EventArgs^ e) {
	
	try {
		con->Open();
		SQLiteDataReader^ myReader;
		String^ command1 = "delete from id_tab where otp_id = '" + this->id_box2->Text + "';";
		String^ command2 = "delete from name_tab where id = '" + this->id_box2->Text + "';";
		String^ command3 = "delete from prih_tab where id = '" + this->id_box2->Text + "';";
		String^ command4 = "delete from otp_tab where id = '" + this->id_box2->Text + "';";
		String^ command5 = "delete from otchet_tab where id = '" + this->id_box2->Text + "';";
		SQLiteCommand^ cmd1 = gcnew SQLiteCommand(command1, con);
		myReader = cmd1->ExecuteReader();
		SQLiteCommand^ cmd2 = gcnew SQLiteCommand(command2, con);
		myReader = cmd2->ExecuteReader();
		SQLiteCommand^ cmd3 = gcnew SQLiteCommand(command3, con);
		myReader = cmd3->ExecuteReader();
		SQLiteCommand^ cmd4 = gcnew SQLiteCommand(command4, con);
		myReader = cmd4->ExecuteReader();
		SQLiteCommand^ cmd5 = gcnew SQLiteCommand(command5, con);
		myReader = cmd5->ExecuteReader();
		this->id_box2->Clear();
		while (myReader->Read())
		{
		}
		con->Close();

		con->Open();
		SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
		SQLiteCommand^ cmd6 = gcnew SQLiteCommand("Select * From otp_tab;", con);
		sda->SelectCommand = cmd6;
		System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
		sda->Fill(dbdataset);
		BindingSource^ bSource = gcnew BindingSource();
		bSource->DataSource = dbdataset;
		dataGridView1->DataSource = bSource;
		sda->Update(dbdataset);
	}
	finally {
		if (con != nullptr)
		{
			con->Close();
		}
	}
}
private: System::Void excel_Click(System::Object^ sender, System::EventArgs^ e) {
	Microsoft::Office::Interop::Excel::Application^ exApp = gcnew Microsoft::Office::Interop::Excel::ApplicationClass();
	exApp->Workbooks->Add(Type::Missing);
	Microsoft::Office::Interop::Excel::Worksheet^ wsh = (Microsoft::Office::Interop::Excel::Worksheet^)exApp->ActiveSheet;
	int i, j;
	for (i = 0; i < dataGridView1->RowCount; i++)
	{
		for (j = 0; j < dataGridView1->ColumnCount; j++)
		{
			wsh->Cells[1, j + 1] = dataGridView1->Columns[j]->HeaderText->ToString();
			wsh->Cells[i + 2, j + 1] = dataGridView1[j, i]->Value->ToString();
		}
	}
	exApp->Visible = true;
}
};
}
