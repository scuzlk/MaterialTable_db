#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Data::SQLite;
using namespace Microsoft::Office::Interop::Excel;


namespace UserTest {

	/// <summary>
	/// ������ ��� Control1
	/// </summary>
	public ref class Control1 : public System::Windows::Forms::UserControl
	{

	private:String^ conect = "Data Source =.\\mat.db";
	private:SQLiteConnection^ con = gcnew SQLiteConnection(conect);

	public:
		Control1(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Control1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel2;
	protected:
	private: System::Windows::Forms::Label^ mea_lab;
	private: System::Windows::Forms::Label^ name_lab;
	private: System::Windows::Forms::Label^ id_lab;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ id_box;
	private: System::Windows::Forms::TextBox^ name_box;
	private: System::Windows::Forms::TextBox^ mea_box;
	private: System::Windows::Forms::Button^ tabl_select;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::TableLayoutPanel^ tableLayoutPanel1;
	private: System::Windows::Forms::Button^ del_but;
	private: System::Windows::Forms::Button^ insert_but;
	private: System::Windows::Forms::Button^ update_but;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::ToolTip^ toolTip1;
	private: System::Windows::Forms::Button^ excel;

	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle9 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle10 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->mea_lab = (gcnew System::Windows::Forms::Label());
			this->name_lab = (gcnew System::Windows::Forms::Label());
			this->id_lab = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->id_box = (gcnew System::Windows::Forms::TextBox());
			this->name_box = (gcnew System::Windows::Forms::TextBox());
			this->mea_box = (gcnew System::Windows::Forms::TextBox());
			this->tabl_select = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->del_but = (gcnew System::Windows::Forms::Button());
			this->insert_but = (gcnew System::Windows::Forms::Button());
			this->update_but = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->toolTip1 = (gcnew System::Windows::Forms::ToolTip(this->components));
			this->excel = (gcnew System::Windows::Forms::Button());
			this->panel2->SuspendLayout();
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->panel3->SuspendLayout();
			this->tableLayoutPanel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel2
			// 
			this->panel2->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->panel2->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel2->Controls->Add(this->mea_lab);
			this->panel2->Controls->Add(this->name_lab);
			this->panel2->Controls->Add(this->id_lab);
			this->panel2->Controls->Add(this->label2);
			this->panel2->Controls->Add(this->id_box);
			this->panel2->Controls->Add(this->name_box);
			this->panel2->Controls->Add(this->mea_box);
			this->panel2->Location = System::Drawing::Point(801, 67);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(402, 262);
			this->panel2->TabIndex = 14;
			// 
			// mea_lab
			// 
			this->mea_lab->AutoSize = true;
			this->mea_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->mea_lab->Location = System::Drawing::Point(26, 175);
			this->mea_lab->Name = L"mea_lab";
			this->mea_lab->Size = System::Drawing::Size(173, 21);
			this->mea_lab->TabIndex = 6;
			this->mea_lab->Text = L"������� ���������";
			// 
			// name_lab
			// 
			this->name_lab->AutoSize = true;
			this->name_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->name_lab->Location = System::Drawing::Point(67, 119);
			this->name_lab->Name = L"name_lab";
			this->name_lab->Size = System::Drawing::Size(132, 21);
			this->name_lab->TabIndex = 5;
			this->name_lab->Text = L"������������";
			// 
			// id_lab
			// 
			this->id_lab->AutoSize = true;
			this->id_lab->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->id_lab->Location = System::Drawing::Point(174, 67);
			this->id_lab->Name = L"id_lab";
			this->id_lab->Size = System::Drawing::Size(25, 21);
			this->id_lab->TabIndex = 4;
			this->id_lab->Text = L"Id";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(156, 9);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(71, 21);
			this->label2->TabIndex = 0;
			this->label2->Text = L"������:";
			// 
			// id_box
			// 
			this->id_box->Location = System::Drawing::Point(221, 67);
			this->id_box->Multiline = true;
			this->id_box->Name = L"id_box";
			this->id_box->Size = System::Drawing::Size(137, 32);
			this->id_box->TabIndex = 1;
			// 
			// name_box
			// 
			this->name_box->Location = System::Drawing::Point(221, 119);
			this->name_box->Multiline = true;
			this->name_box->Name = L"name_box";
			this->name_box->Size = System::Drawing::Size(137, 32);
			this->name_box->TabIndex = 2;
			// 
			// mea_box
			// 
			this->mea_box->Location = System::Drawing::Point(221, 175);
			this->mea_box->Multiline = true;
			this->mea_box->Name = L"mea_box";
			this->mea_box->Size = System::Drawing::Size(137, 32);
			this->mea_box->TabIndex = 3;
			// 
			// tabl_select
			// 
			this->tabl_select->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->tabl_select->BackColor = System::Drawing::Color::LightSalmon;
			this->tabl_select->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->tabl_select->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->tabl_select->Location = System::Drawing::Point(959, 7);
			this->tabl_select->Name = L"tabl_select";
			this->tabl_select->Size = System::Drawing::Size(255, 41);
			this->tabl_select->TabIndex = 6;
			this->tabl_select->Text = L"������� �������";
			this->tabl_select->UseVisualStyleBackColor = false;
			this->tabl_select->Click += gcnew System::EventHandler(this, &Control1::tabl_select_Click);
			// 
			// panel1
			// 
			this->panel1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->panel1->BackColor = System::Drawing::Color::Linen;
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->tabl_select);
			this->panel1->Location = System::Drawing::Point(3, 3);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(1230, 58);
			this->panel1->TabIndex = 13;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Ubuntu", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(21, 11);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(309, 29);
			this->label1->TabIndex = 7;
			this->label1->Text = L"������������ ����������";
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			dataGridViewCellStyle9->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle9->BackColor = System::Drawing::SystemColors::Control;
			dataGridViewCellStyle9->Font = (gcnew System::Drawing::Font(L"Ubuntu Light", 8.999999F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle9->ForeColor = System::Drawing::SystemColors::WindowText;
			dataGridViewCellStyle9->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle9->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle9->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle10->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle10->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle10->Font = (gcnew System::Drawing::Font(L"Ubuntu", 8.999999F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle10->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle10->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle10->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle10->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle10;
			this->dataGridView1->Location = System::Drawing::Point(3, 67);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(792, 654);
			this->dataGridView1->TabIndex = 12;
			// 
			// panel3
			// 
			this->panel3->Anchor = System::Windows::Forms::AnchorStyles::Right;
			this->panel3->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel3->Controls->Add(this->tableLayoutPanel1);
			this->panel3->Controls->Add(this->label3);
			this->panel3->Location = System::Drawing::Point(801, 403);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(402, 112);
			this->panel3->TabIndex = 15;
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 3;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				50.3876F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				49.6124F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				144)));
			this->tableLayoutPanel1->Controls->Add(this->del_but, 2, 0);
			this->tableLayoutPanel1->Controls->Add(this->insert_but, 0, 0);
			this->tableLayoutPanel1->Controls->Add(this->update_but, 1, 0);
			this->tableLayoutPanel1->Location = System::Drawing::Point(7, 53);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 1;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 50)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(394, 43);
			this->tableLayoutPanel1->TabIndex = 12;
			// 
			// del_but
			// 
			this->del_but->BackColor = System::Drawing::Color::LightSalmon;
			this->del_but->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->del_but->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->del_but->Location = System::Drawing::Point(252, 3);
			this->del_but->Name = L"del_but";
			this->del_but->Size = System::Drawing::Size(114, 31);
			this->del_but->TabIndex = 10;
			this->del_but->Text = L"�������";
			this->toolTip1->SetToolTip(this->del_but, L"��� �������� ������ ���������� ������ ������ id");
			this->del_but->UseVisualStyleBackColor = false;
			this->del_but->Click += gcnew System::EventHandler(this, &Control1::del_but_Click);
			// 
			// insert_but
			// 
			this->insert_but->BackColor = System::Drawing::Color::LightSalmon;
			this->insert_but->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->insert_but->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->insert_but->Location = System::Drawing::Point(3, 3);
			this->insert_but->Name = L"insert_but";
			this->insert_but->Size = System::Drawing::Size(114, 31);
			this->insert_but->TabIndex = 4;
			this->insert_but->Text = L"��������";
			this->insert_but->UseVisualStyleBackColor = false;
			this->insert_but->Click += gcnew System::EventHandler(this, &Control1::insert_but_Click);
			// 
			// update_but
			// 
			this->update_but->BackColor = System::Drawing::Color::LightSalmon;
			this->update_but->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->update_but->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->update_but->Location = System::Drawing::Point(128, 3);
			this->update_but->Name = L"update_but";
			this->update_but->Size = System::Drawing::Size(114, 31);
			this->update_but->TabIndex = 9;
			this->update_but->Text = L"��������";
			this->update_but->UseVisualStyleBackColor = false;
			this->update_but->Click += gcnew System::EventHandler(this, &Control1::update_but_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(109, 15);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(189, 21);
			this->label3->TabIndex = 0;
			this->label3->Text = L"���������� ��������";
			// 
			// toolTip1
			// 
			this->toolTip1->AutomaticDelay = 400;
			// 
			// excel
			// 
			this->excel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->excel->BackColor = System::Drawing::Color::Tomato;
			this->excel->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->excel->Font = (gcnew System::Drawing::Font(L"Ubuntu", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->excel->Location = System::Drawing::Point(915, 552);
			this->excel->Name = L"excel";
			this->excel->Size = System::Drawing::Size(208, 37);
			this->excel->TabIndex = 16;
			this->excel->Text = L"��������� � Excel";
			this->excel->UseVisualStyleBackColor = false;
			this->excel->Click += gcnew System::EventHandler(this, &Control1::excel_Click);
			// 
			// Control1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Snow;
			this->Controls->Add(this->excel);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->panel3);
			this->Name = L"Control1";
			this->Size = System::Drawing::Size(1237, 725);
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->tableLayoutPanel1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void tabl_select_Click(System::Object^ sender, System::EventArgs^ e) {	
		try {
			con->Open();
			SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
			SQLiteCommand^ cmd = gcnew SQLiteCommand("Select * From name_tab;", con);
			sda->SelectCommand = cmd;
			System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
			sda->Fill(dbdataset);
			BindingSource^ bSource = gcnew BindingSource();
			bSource->DataSource = dbdataset;
			dataGridView1->DataSource = bSource;
			sda->Update(dbdataset);
		}
		finally {
			if (con != nullptr)
			{
				con->Close();
			}
		}
	}
private: System::Void insert_but_Click(System::Object^ sender, System::EventArgs^ e) {
	
	try {
		con->Open();
		SQLiteDataReader^ myReader;
		String^ command1 = "insert into name_tab(id,������������, [������� ���������]) \
values ('" + this->id_box->Text + "','" + this->name_box->Text + "', '" + this->mea_box->Text + "');";
		SQLiteCommand^ cmd1 = gcnew SQLiteCommand(command1, con);
		myReader = cmd1->ExecuteReader();
		this->name_box->Clear();
		this->id_box->Clear();
		this->mea_box->Clear();
		while (myReader->Read())
		{
		}
		con->Close();
		//����� ������� Select ����� ��� ����� �����������, � �� �� ��������� ������ �� �� ����� ��������
		con->Open();
		SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
		SQLiteCommand^ cmd6 = gcnew SQLiteCommand("Select * From name_tab;", con);
		sda->SelectCommand = cmd6;
		
		System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
		sda->Fill(dbdataset);
		BindingSource^ bSource = gcnew BindingSource();
		bSource->DataSource = dbdataset;
		dataGridView1->DataSource = bSource;
		sda->Update(dbdataset);
	}
	finally {
		if (con != nullptr)
		{
			con->Close();
		}
	}
}
private: System::Void update_but_Click(System::Object^ sender, System::EventArgs^ e) {
	
	try {
		con->Open();
		SQLiteDataReader^ myReader;
		//UPDATE test_table Set ������������ = '', [������� ���������] = '' where id = 1;
		String^ command1 = "update name_tab set ������������ = '" + this->name_box->Text + "', [������� ���������] ='" + this->mea_box->Text + "' where id = '"+this->id_box->Text+"';";
		String^ command2 = "update prih_tab set ������������ = '" + this->name_box->Text + "' where id = '" + this->id_box->Text + "';";
		String^ command3 = "update otp_tab set ������������ = '" + this->name_box->Text + "' where id = '" + this->id_box->Text + "';";
		SQLiteCommand^ cmd1 = gcnew SQLiteCommand(command1, con);
		myReader = cmd1->ExecuteReader();
		SQLiteCommand^ cmd2 = gcnew SQLiteCommand(command2, con);
		myReader = cmd2->ExecuteReader();
		SQLiteCommand^ cmd3 = gcnew SQLiteCommand(command3, con);
		myReader = cmd3->ExecuteReader();
		this->name_box->Clear();
		this->id_box->Clear();
		this->mea_box->Clear();
		while (myReader->Read())
		{
		}
		con->Close();

		con->Open();
		SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
		SQLiteCommand^ cmd6 = gcnew SQLiteCommand("Select * From name_tab;", con);
		sda->SelectCommand = cmd6;
		System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
		sda->Fill(dbdataset);
		BindingSource^ bSource = gcnew BindingSource();
		bSource->DataSource = dbdataset;
		dataGridView1->DataSource = bSource;
		sda->Update(dbdataset);
	}
	finally {
		if (con != nullptr)
		{
			con->Close();
		}
	}
}
private: System::Void del_but_Click(System::Object^ sender, System::EventArgs^ e) {
	
	try {
		con->Open();
		SQLiteDataReader^ myReader;
		String^ command2 = "delete from name_tab where id = '" + this->id_box->Text + "';";
		String^ command3 = "delete from prih_tab where id = '" + this->id_box->Text + "';";
		String^ command4 = "delete from otp_tab where id = '" + this->id_box->Text + "';";
		SQLiteCommand^ cmd2 = gcnew SQLiteCommand(command2, con);
		myReader = cmd2->ExecuteReader();
		SQLiteCommand^ cmd3 = gcnew SQLiteCommand(command3, con);
		myReader = cmd3->ExecuteReader();
		SQLiteCommand^ cmd4 = gcnew SQLiteCommand(command4, con);
		myReader = cmd4->ExecuteReader();
		this->name_box->Clear();
		this->id_box->Clear();
		this->mea_box->Clear();
		while (myReader->Read())
		{
		}
		con->Close();

		con->Open();
		SQLiteDataAdapter^ sda = gcnew SQLiteDataAdapter();
		SQLiteCommand^ cmd6 = gcnew SQLiteCommand("Select * From name_tab;", con);
		sda->SelectCommand = cmd6;
		System::Data::DataTable^ dbdataset = gcnew System::Data::DataTable();
		sda->Fill(dbdataset);
		BindingSource^ bSource = gcnew BindingSource();
		bSource->DataSource = dbdataset;
		dataGridView1->DataSource = bSource;
		sda->Update(dbdataset);
	}
	finally {
		if (con != nullptr)
		{
			con->Close();
		}
	}
}

private: System::Void excel_Click(System::Object^ sender, System::EventArgs^ e) {
	Microsoft::Office::Interop::Excel::Application^ exApp = gcnew Microsoft::Office::Interop::Excel::ApplicationClass();
	exApp->Workbooks->Add(Type::Missing);
	Microsoft::Office::Interop::Excel::Worksheet^ wsh = (Microsoft::Office::Interop::Excel::Worksheet^)exApp->ActiveSheet;
	int i, j;
	for (i = 0; i < dataGridView1->RowCount; i++)
	{
		for (j = 0; j < dataGridView1->ColumnCount; j++)
		{
			wsh->Cells[1, j + 1] = dataGridView1->Columns[j]->HeaderText->ToString();
			wsh->Cells[i + 2, j + 1] = dataGridView1[j, i]->Value->ToString();
		}
	}
	exApp->Visible = true;
}
};
}
