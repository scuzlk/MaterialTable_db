﻿#pragma once

using namespace System;

namespace UserTest {
	public ref class Class1
	{
		// TODO: Добавьте сюда свои методы для этого класса.
	};
}
